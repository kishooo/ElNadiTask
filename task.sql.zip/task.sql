-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 20, 2023 at 02:03 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `task`
--

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` bigint(24) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Description` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `Name`, `Description`) VALUES
(4, 'Math', 'ahmed mostafa elkashlan'),
(5, 'English ', 'this easy course ');

-- --------------------------------------------------------

--
-- Table structure for table `gradeitem`
--

CREATE TABLE `gradeitem` (
  `id` bigint(24) NOT NULL,
  `Name` varchar(40) NOT NULL,
  `MaxDegree` int(11) NOT NULL,
  `type` varchar(40) NOT NULL,
  `CID` bigint(24) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gradeitem`
--

INSERT INTO `gradeitem` (`id`, `Name`, `MaxDegree`, `type`, `CID`) VALUES
(0, 'Oral', 10, 'Midterm exam', 4),
(0, 'writing', 10, 'final', 5);

-- --------------------------------------------------------

--
-- Table structure for table `level`
--

CREATE TABLE `level` (
  `id` bigint(24) NOT NULL,
  `Name` varchar(40) NOT NULL,
  `Number` int(11) NOT NULL,
  `Description` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `level`
--

INSERT INTO `level` (`id`, `Name`, `Number`, `Description`) VALUES
(1, 'level 4 ', 4, 'this last level for the university ');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` bigint(24) NOT NULL,
  `FullNmae` varchar(60) NOT NULL,
  `DateBirth` date NOT NULL,
  `Email` varchar(40) NOT NULL,
  `Level` varchar(13) NOT NULL,
  `LID` bigint(24) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `FullNmae`, `DateBirth`, `Email`, `Level`, `LID`) VALUES
(3, 'ahmed mostafa elkashlan', '2023-02-01', 'ahmed@gmail.com', 'level 4', 1);

-- --------------------------------------------------------

--
-- Table structure for table `studnetcourse`
--

CREATE TABLE `studnetcourse` (
  `id` bigint(24) NOT NULL,
  `SID` bigint(24) NOT NULL,
  `CID` bigint(24) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studnetcourse`
--

INSERT INTO `studnetcourse` (`id`, `SID`, `CID`) VALUES
(1, 3, 4),
(2, 3, 5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gradeitem`
--
ALTER TABLE `gradeitem`
  ADD KEY `CID` (`CID`);

--
-- Indexes for table `level`
--
ALTER TABLE `level`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`),
  ADD KEY `LID` (`LID`);

--
-- Indexes for table `studnetcourse`
--
ALTER TABLE `studnetcourse`
  ADD PRIMARY KEY (`id`),
  ADD KEY `SID` (`SID`),
  ADD KEY `CID` (`CID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` bigint(24) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `level`
--
ALTER TABLE `level`
  MODIFY `id` bigint(24) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` bigint(24) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `studnetcourse`
--
ALTER TABLE `studnetcourse`
  MODIFY `id` bigint(24) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `gradeitem`
--
ALTER TABLE `gradeitem`
  ADD CONSTRAINT `gradeitem_ibfk_1` FOREIGN KEY (`CID`) REFERENCES `course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_2` FOREIGN KEY (`LID`) REFERENCES `level` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `studnetcourse`
--
ALTER TABLE `studnetcourse`
  ADD CONSTRAINT `studnetcourse_ibfk_1` FOREIGN KEY (`CID`) REFERENCES `course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `studnetcourse_ibfk_2` FOREIGN KEY (`SID`) REFERENCES `student` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
